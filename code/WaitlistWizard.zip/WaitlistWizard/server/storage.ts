import { users, type User, type InsertUser, loanApplications, type LoanApplication, type InsertLoanApplication } from "@shared/schema";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Loan Application methods
  createLoanApplication(application: InsertLoanApplication): Promise<LoanApplication>;
  getLoanApplication(id: number): Promise<LoanApplication | undefined>;
  getAllLoanApplications(): Promise<LoanApplication[]>;
  updateLoanApplicationStatus(id: number, status: string): Promise<LoanApplication | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private loanApplications: Map<number, LoanApplication>;
  currentUserId: number;
  currentApplicationId: number;

  constructor() {
    this.users = new Map();
    this.loanApplications = new Map();
    this.currentUserId = 1;
    this.currentApplicationId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  async createLoanApplication(application: InsertLoanApplication): Promise<LoanApplication> {
    const id = this.currentApplicationId++;
    const now = new Date();
    const loanApplication: LoanApplication = { 
      ...application, 
      id, 
      status: "under_review", 
      createdAt: now 
    };
    this.loanApplications.set(id, loanApplication);
    return loanApplication;
  }
  
  async getLoanApplication(id: number): Promise<LoanApplication | undefined> {
    return this.loanApplications.get(id);
  }
  
  async getAllLoanApplications(): Promise<LoanApplication[]> {
    return Array.from(this.loanApplications.values());
  }
  
  async updateLoanApplicationStatus(id: number, status: string): Promise<LoanApplication | undefined> {
    const application = this.loanApplications.get(id);
    if (!application) return undefined;
    
    const updatedApplication = { ...application, status };
    this.loanApplications.set(id, updatedApplication);
    return updatedApplication;
  }
}

export const storage = new MemStorage();
