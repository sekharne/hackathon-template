import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { applicationFormSchema } from "@shared/schema";
import type { ApplicationFormData } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes - prefix all with /api
  app.get("/api/status", (_req, res) => {
    res.json({ status: "ok" });
  });

  // Create a new loan application
  app.post("/api/applications", async (req, res) => {
    try {
      // Validate the request body
      const validatedData = applicationFormSchema.parse(req.body);
      
      // Format the data to match our database schema
      const applicationData: any = { ...validatedData };
      delete applicationData.termsAgreement; // Don't store the terms agreement flag
      
      // Convert loanTerm from string to number
      applicationData.loanTerm = parseInt(validatedData.loanTerm);
      
      // Store the application
      const application = await storage.createLoanApplication(applicationData);
      
      res.status(201).json({ 
        id: application.id,
        status: application.status 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.format() 
        });
      }
      console.error("Error creating application:", error);
      res.status(500).json({ message: "Failed to create application" });
    }
  });

  // Get application by ID
  app.get("/api/applications/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid application ID" });
      }

      const application = await storage.getLoanApplication(id);
      if (!application) {
        return res.status(404).json({ message: "Application not found" });
      }

      res.json(application);
    } catch (error) {
      console.error("Error fetching application:", error);
      res.status(500).json({ message: "Failed to fetch application" });
    }
  });
  
  // Calculate loan payment
  app.post("/api/calculate", (req, res) => {
    try {
      const schema = z.object({
        loanAmount: z.number().min(1),
        loanTerm: z.number().min(1),
        interestRate: z.number().min(0.1),
      });
      
      const { loanAmount, loanTerm, interestRate } = schema.parse(req.body);
      
      // Calculate monthly payment
      const monthlyRate = interestRate / 100 / 12;
      const numPayments = loanTerm;
      const monthlyPayment = loanAmount * monthlyRate / (1 - Math.pow(1 + monthlyRate, -numPayments));
      const totalPayment = monthlyPayment * numPayments;
      const totalInterest = totalPayment - loanAmount;
      
      res.json({
        monthlyPayment: parseFloat(monthlyPayment.toFixed(2)),
        totalInterest: parseFloat(totalInterest.toFixed(2)),
        totalPayment: parseFloat(totalPayment.toFixed(2)),
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.format() 
        });
      }
      res.status(500).json({ message: "Failed to calculate loan payment" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
