import { Header } from "@/components/ui/header";
import { Footer } from "@/components/ui/footer";
import { BenefitsSection } from "@/components/ui/benefits-section";
import { LoanCalculator } from "@/components/ui/loan-calculator";
import { ApplicationForm } from "@/components/ui/application-form";
import { TestimonialsSection } from "@/components/ui/testimonials-section";
import { FaqSection } from "@/components/ui/faq-section";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-primary text-white py-12 md:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Financial Solutions Tailored For You
              </h2>
              <p className="text-lg mb-6">
                Apply today and get access to personalized loan options with competitive rates.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <a
                  href="#application-form"
                  className="bg-white text-primary px-6 py-3 rounded-md font-semibold hover:bg-gray-100 transition-colors text-center"
                >
                  Start Application
                </a>
                <a
                  href="#calculator"
                  className="border border-white text-white px-6 py-3 rounded-md font-semibold hover:bg-white hover:text-primary transition-colors text-center"
                >
                  Calculate Rate
                </a>
              </div>
            </div>
            <div className="hidden md:block">
              <img
                src="https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=400&q=80"
                alt="Financial planning illustration"
                className="rounded-lg shadow-lg"
                width="600"
                height="400"
              />
            </div>
          </div>
        </div>
      </section>
      
      {/* Benefits Section */}
      <BenefitsSection />
      
      {/* Calculator Section */}
      <section id="calculator" className="py-12 bg-gray-50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-lg shadow-md p-6 md:p-8">
            <h2 className="text-2xl font-bold mb-6 text-center">Loan Calculator</h2>
            <p className="text-gray-600 mb-8 text-center">
              Estimate your monthly payments and total interest
            </p>
            <LoanCalculator />
          </div>
        </div>
      </section>
      
      {/* Application Form Section */}
      <section id="application-form" className="py-12 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-4">
            Start Your Application
          </h2>
          <p className="text-center text-gray-600 mb-8">
            Complete the form below to apply for your loan. The process takes just a few minutes.
          </p>
          <ApplicationForm />
        </div>
      </section>
      
      {/* Testimonials Section */}
      <TestimonialsSection />
      
      {/* FAQ Section */}
      <FaqSection />
      
      <Footer />
    </div>
  );
}
