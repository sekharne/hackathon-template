import { useEffect, useState } from "react";
import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { CheckCircle, Clock, AlertTriangle } from "lucide-react";
import { Header } from "@/components/ui/header";
import { Footer } from "@/components/ui/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { LoanApplication } from "@shared/schema";

export default function ApplicationStatus() {
  const [, params] = useRoute<{ id: string }>("/application/:id");
  const applicationId = params?.id ? parseInt(params.id) : undefined;

  const { data: application, isLoading, error } = useQuery<LoanApplication>({
    queryKey: [applicationId ? `/api/applications/${applicationId}` : null],
    enabled: !!applicationId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow py-12 bg-gray-50">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-8">
              <Skeleton className="h-10 w-1/3 mx-auto mb-4" />
              <Skeleton className="h-6 w-2/3 mx-auto" />
            </div>
            <Card>
              <CardContent className="pt-6">
                <Skeleton className="h-6 w-1/4 mb-2" />
                <Skeleton className="h-8 w-1/2 mb-6" />
                <Skeleton className="h-6 w-1/4 mb-2" />
                <Skeleton className="h-8 w-1/3 mb-6" />
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (error || !applicationId) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow py-12 bg-gray-50">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-8">
                  <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
                  <h2 className="text-2xl font-bold mb-3">Application Not Found</h2>
                  <p className="text-gray-600 mb-6">
                    We couldn't find the application you're looking for. It may have been removed or the link is incorrect.
                  </p>
                  <Button asChild>
                    <Link href="/">Return Home</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const formatDate = (dateString: Date) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  // Format application status for display
  const getStatusDisplay = (status: string) => {
    switch (status) {
      case 'approved':
        return {
          icon: <CheckCircle className="h-8 w-8 text-green-500" />,
          label: 'Approved',
          color: 'text-green-600',
          description: 'Your loan has been approved! We will contact you shortly with next steps.'
        };
      case 'rejected':
        return {
          icon: <AlertTriangle className="h-8 w-8 text-red-500" />,
          label: 'Not Approved',
          color: 'text-red-600',
          description: 'Unfortunately, we could not approve your application at this time.'
        };
      case 'under_review':
      default:
        return {
          icon: <Clock className="h-8 w-8 text-amber-500" />,
          label: 'Under Review',
          color: 'text-amber-600',
          description: 'Your application is currently being reviewed. This process typically takes 1-2 business days.'
        };
    }
  };

  const statusDisplay = getStatusDisplay(application?.status || 'under_review');

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow py-12 bg-gray-50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">Application Status</h1>
            <p className="text-gray-600">
              Track the status of your loan application
            </p>
          </div>
          
          {application && (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center p-4">
                  {statusDisplay.icon}
                  <h2 className="text-xl font-bold mt-4">Application {statusDisplay.label}</h2>
                  <p className="text-gray-600 mt-2">{statusDisplay.description}</p>
                </div>
                
                <div className="border-t border-gray-200 mt-6 pt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Application ID:</p>
                      <p className="text-lg font-semibold">FP-{application.id.toString().padStart(8, '0')}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Submitted On:</p>
                      <p className="font-medium">{formatDate(application.createdAt)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Loan Amount:</p>
                      <p className="font-medium">${application.loanAmount.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Loan Term:</p>
                      <p className="font-medium">{application.loanTerm} months</p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-8 text-center">
                  <p className="text-gray-600 mb-4">
                    We've sent a confirmation email to <span className="font-medium">{application.email}</span>. 
                    You can check this page anytime to see updates on your application status.
                  </p>
                  <Button asChild>
                    <Link href="/">Return to Home</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}
