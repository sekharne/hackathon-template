import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "How long does the application process take?",
    answer:
      "The online application takes just 5-10 minutes to complete. Once submitted, you'll typically receive a decision within 1-2 business days, depending on the verification needs of your application."
  },
  {
    question: "What documents will I need to provide?",
    answer:
      "You'll need to provide proof of identity (government-issued ID), proof of income (recent pay stubs or tax returns), and proof of residence (utility bill or bank statement). Depending on your loan purpose, additional documentation may be required."
  },
  {
    question: "Is there a fee to apply?",
    answer:
      "No, there is no application fee. If your loan is approved and you decide to proceed, there may be an origination fee which will be clearly disclosed before you accept the loan terms."
  },
  {
    question: "How are interest rates determined?",
    answer:
      "Interest rates are determined based on several factors including your credit score, income, loan amount, loan term, and current market conditions. We offer competitive rates tailored to your financial profile."
  },
  {
    question: "Can I pay off my loan early?",
    answer:
      "Yes, you can pay off your loan early without any prepayment penalties. Early repayment can save you money on interest over the life of the loan."
  }
];

export function FaqSection() {
  return (
    <section className="py-12 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-10">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="space-y-4">
          {faqs.map((faq, index) => (
            <AccordionItem key={index} value={`item-${index}`} className="border border-gray-200 rounded-lg">
              <AccordionTrigger className="px-6 py-4 font-semibold hover:no-underline">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="px-6 pb-4 text-gray-600">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
