import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Menu } from "lucide-react";

export function Header() {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-6 w-6 mr-2 text-primary"
          >
            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
            <polyline points="9 22 9 12 15 12 15 22"></polyline>
          </svg>
          <h1 className="text-2xl font-bold text-primary">FinancePro</h1>
        </div>
        
        <nav className="hidden md:block">
          <ul className="flex space-x-8">
            <li>
              <a href="#" className="font-medium text-neutral-600 hover:text-primary transition-colors">
                Products
              </a>
            </li>
            <li>
              <a href="#" className="font-medium text-neutral-600 hover:text-primary transition-colors">
                About Us
              </a>
            </li>
            <li>
              <a href="#" className="font-medium text-neutral-600 hover:text-primary transition-colors">
                Resources
              </a>
            </li>
            <li>
              <a href="#application-form" className="font-medium bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition-colors">
                Apply Now
              </a>
            </li>
          </ul>
        </nav>
        
        <Sheet>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" size="icon">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent>
            <div className="flex flex-col space-y-4 mt-8">
              <Link href="#" className="px-2 py-1 rounded-md hover:bg-gray-100">
                Products
              </Link>
              <Link href="#" className="px-2 py-1 rounded-md hover:bg-gray-100">
                About Us
              </Link>
              <Link href="#" className="px-2 py-1 rounded-md hover:bg-gray-100">
                Resources
              </Link>
              <Link 
                href="#application-form" 
                className="bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition-colors text-center"
              >
                Apply Now
              </Link>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}
