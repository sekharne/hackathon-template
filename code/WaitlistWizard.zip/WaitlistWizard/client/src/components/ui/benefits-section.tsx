import { Check, Zap, Shield } from "lucide-react";

const benefits = [
  {
    icon: <Check />,
    title: "Competitive Rates",
    description:
      "Our rates are among the most competitive in the industry, saving you money over time."
  },
  {
    icon: <Zap />,
    title: "Fast Approval",
    description:
      "Get approved in minutes, not days. Our streamlined process means faster access to funds."
  },
  {
    icon: <Shield />,
    title: "Secure Process",
    description:
      "Your information is protected with bank-level security and encryption throughout the application."
  }
];

export function BenefitsSection() {
  return (
    <section className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-10">
          Why Choose FinancePro?
        </h2>
        <div className="grid md:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <div
              key={index}
              className="text-center p-6 rounded-lg hover:shadow-md transition-shadow"
            >
              <div className="bg-primary/80 inline-flex p-3 rounded-full text-white mb-4">
                {benefit.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
              <p className="text-gray-600">{benefit.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
