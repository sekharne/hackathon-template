import { Star, StarHalf } from "lucide-react";

const testimonials = [
  {
    rating: 5,
    comment: "The application process was incredibly smooth. I was approved quickly and the rates were better than I expected!",
    name: "Michael S.",
    loanType: "Debt Consolidation Loan",
    initial: "M"
  },
  {
    rating: 4.5,
    comment: "FinancePro helped me finance my home renovation project. Their customer service team was super helpful throughout the entire process.",
    name: "Jennifer L.",
    loanType: "Home Improvement Loan",
    initial: "J"
  },
  {
    rating: 5,
    comment: "As a small business owner, I needed quick financing to expand. FinancePro delivered great terms and made the process hassle-free.",
    name: "Robert T.",
    loanType: "Business Loan",
    initial: "R"
  }
];

export function TestimonialsSection() {
  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-10">
          What Our Customers Say
        </h2>
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex text-primary mb-4">
                {[...Array(Math.floor(testimonial.rating))].map((_, i) => (
                  <Star key={i} className="fill-primary" />
                ))}
                {testimonial.rating % 1 !== 0 && <StarHalf className="fill-primary" />}
              </div>
              <p className="text-gray-600 mb-4">"{testimonial.comment}"</p>
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-primary font-bold mr-3">
                  {testimonial.initial}
                </div>
                <div>
                  <p className="font-semibold">{testimonial.name}</p>
                  <p className="text-sm text-gray-500">{testimonial.loanType}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
