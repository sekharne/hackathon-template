import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { Slider } from "@/components/ui/slider";
import { apiRequest } from "@/lib/queryClient";

interface CalculationResult {
  monthlyPayment: number;
  totalInterest: number;
  totalPayment: number;
}

export function LoanCalculator() {
  const { toast } = useToast();
  const [loanAmount, setLoanAmount] = useState(25000);
  const [loanTerm, setLoanTerm] = useState(36);
  const [interestRate, setInterestRate] = useState(5.9);
  const [result, setResult] = useState<CalculationResult>({
    monthlyPayment: 0,
    totalInterest: 0,
    totalPayment: 0
  });
  const [isCalculating, setIsCalculating] = useState(false);

  const calculateLoan = async () => {
    try {
      setIsCalculating(true);
      const response = await apiRequest('POST', '/api/calculate', {
        loanAmount,
        loanTerm,
        interestRate
      });
      
      const data = await response.json();
      setResult(data);
    } catch (error) {
      toast({
        title: "Calculation Error",
        description: "There was an error calculating your loan. Please try again.",
        variant: "destructive"
      });
      console.error("Error calculating loan:", error);
    } finally {
      setIsCalculating(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      calculateLoan();
    }, 500);
    
    return () => clearTimeout(timer);
  }, [loanAmount, loanTerm, interestRate]);

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  };

  return (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium mb-2" htmlFor="loan-amount">
          Loan Amount: {formatCurrency(loanAmount)}
        </label>
        <Slider
          id="loan-amount"
          min={5000}
          max={100000}
          step={1000}
          defaultValue={[loanAmount]}
          onValueChange={(values) => setLoanAmount(values[0])}
          className="w-full"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>$5,000</span>
          <span>$100,000</span>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2" htmlFor="loan-term">
          Loan Term: {loanTerm} months
        </label>
        <Slider
          id="loan-term"
          min={12}
          max={84}
          step={12}
          defaultValue={[loanTerm]}
          onValueChange={(values) => setLoanTerm(values[0])}
          className="w-full"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>12 months</span>
          <span>84 months</span>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2" htmlFor="interest-rate">
          Interest Rate: {interestRate.toFixed(1)}%
        </label>
        <Slider
          id="interest-rate"
          min={2.9}
          max={18.9}
          step={0.1}
          defaultValue={[interestRate]}
          onValueChange={(values) => setInterestRate(values[0])}
          className="w-full"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>2.9%</span>
          <span>18.9%</span>
        </div>
      </div>

      <div className="mt-8 pt-6 border-t border-gray-200">
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gray-50 p-4 rounded-md text-center">
            <p className="text-sm text-gray-500 mb-1">Monthly Payment</p>
            <p className="text-2xl font-bold text-primary">
              {isCalculating ? (
                <span className="animate-pulse">Calculating...</span>
              ) : (
                formatCurrency(result.monthlyPayment)
              )}
            </p>
          </div>
          <div className="bg-gray-50 p-4 rounded-md text-center">
            <p className="text-sm text-gray-500 mb-1">Total Interest</p>
            <p className="text-2xl font-bold text-primary">
              {isCalculating ? (
                <span className="animate-pulse">Calculating...</span>
              ) : (
                formatCurrency(result.totalInterest)
              )}
            </p>
          </div>
        </div>
      </div>

      <div className="text-center mt-6">
        <a
          href="#application-form"
          className="inline-block bg-primary text-white px-6 py-3 rounded-md font-semibold hover:bg-primary/90 transition-colors"
        >
          Apply Now
        </a>
      </div>
    </div>
  );
}
