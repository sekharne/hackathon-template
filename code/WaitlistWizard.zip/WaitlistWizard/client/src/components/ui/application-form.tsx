import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { CheckIcon, AlertCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { applicationFormSchema } from "@shared/schema";
import type { ApplicationFormData } from "@shared/schema";

export function ApplicationForm() {
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [applicationId, setApplicationId] = useState<number | null>(null);
  const [applicationStatus, setApplicationStatus] = useState<string | null>(null);
  const { toast } = useToast();
  const [, navigate] = useLocation();

  const form = useForm<ApplicationFormData>({
    resolver: zodResolver(applicationFormSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      address: "",
      city: "",
      zip: "",
      employmentStatus: "employed",
      employer: "",
      annualIncome: 0,
      creditScore: "unknown",
      loanPurpose: "debt-consolidation",
      loanAmount: 10000,
      loanTerm: "36",
      termsAgreement: false,
    },
    mode: "onChange",
  });

  const totalSteps = 4;

  // Function to go to the next step
  const nextStep = async () => {
    const currentStepFields = getFieldsForStep(currentStep);
    const result = await form.trigger(currentStepFields as any);

    if (result) {
      setCurrentStep((prev) => Math.min(prev + 1, totalSteps));
      window.scrollTo(0, document.getElementById("application-form")?.offsetTop || 0);
    } else {
      toast({
        title: "Please fix the errors",
        description: "There are some issues with your inputs that need to be corrected.",
        variant: "destructive",
      });
    }
  };

  // Function to go to the previous step
  const prevStep = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 1));
    window.scrollTo(0, document.getElementById("application-form")?.offsetTop || 0);
  };

  // Get fields for validation based on the current step
  const getFieldsForStep = (step: number) => {
    switch (step) {
      case 1:
        return ["firstName", "lastName", "email", "phone", "address", "city", "zip"];
      case 2:
        return ["employmentStatus", "annualIncome"];
      case 3:
        return ["loanPurpose", "loanAmount", "loanTerm"];
      case 4:
        return ["termsAgreement"];
      default:
        return [];
    }
  };

  // Calculate the progress percentage
  const progressPercent = ((currentStep - 1) / (totalSteps - 1)) * 100;

  // Handle form submission
  const onSubmit = async (data: ApplicationFormData) => {
    try {
      setIsSubmitting(true);
      
      // Convert loanTerm to string for the API
      const formData = {
        ...data,
        annualIncome: Number(data.annualIncome),
        loanAmount: Number(data.loanAmount)
      };

      const response = await apiRequest("POST", "/api/applications", formData);
      const result = await response.json();
      
      setApplicationId(result.id);
      setApplicationStatus(result.status);
      
      toast({
        title: "Application Submitted",
        description: "Your loan application has been successfully submitted.",
      });
      
      // Navigate to status page
      navigate(`/application/${result.id}`);
    } catch (error) {
      console.error("Error submitting application:", error);
      toast({
        title: "Submission Error",
        description: "There was an error submitting your application. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-gray-50 rounded-lg shadow-md p-6 md:p-8">
      {/* Progress Indicator */}
      <div className="mb-8">
        <div className="flex justify-between">
          {Array.from({ length: totalSteps }, (_, i) => i + 1).map((step) => (
            <div key={step} className="flex flex-col items-center">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                  step < currentStep
                    ? "bg-green-600 text-white"
                    : step === currentStep
                    ? "bg-primary text-white"
                    : "bg-gray-200 text-gray-600"
                }`}
              >
                {step < currentStep ? <CheckIcon className="h-5 w-5" /> : step}
              </div>
              <p className="text-sm mt-2">
                {step === 1
                  ? "Personal Info"
                  : step === 2
                  ? "Financial Details"
                  : step === 3
                  ? "Loan Details"
                  : "Review"}
              </p>
            </div>
          ))}
        </div>
        <div className="relative mt-3 mb-6">
          <div className="h-1 bg-gray-200 rounded">
            <div
              className="h-1 bg-primary rounded"
              style={{ width: `${progressPercent}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* Form */}
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          {/* Step 1: Personal Information */}
          {currentStep === 1 && (
            <div>
              <h3 className="text-xl font-semibold mb-6">Personal Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="firstName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>First Name <span className="text-red-500">*</span></FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="lastName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Last Name <span className="text-red-500">*</span></FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Address <span className="text-red-500">*</span></FormLabel>
                      <FormControl>
                        <Input type="email" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number <span className="text-red-500">*</span></FormLabel>
                      <FormControl>
                        <Input type="tel" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem className="md:col-span-2">
                      <FormLabel>Street Address <span className="text-red-500">*</span></FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="city"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>City <span className="text-red-500">*</span></FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="zip"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ZIP Code <span className="text-red-500">*</span></FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="mt-8 flex justify-end">
                <Button type="button" onClick={nextStep}>Continue</Button>
              </div>
            </div>
          )}

          {/* Step 2: Financial Details */}
          {currentStep === 2 && (
            <div>
              <h3 className="text-xl font-semibold mb-6">Financial Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="employmentStatus"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Employment Status <span className="text-red-500">*</span></FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="employed">Employed</SelectItem>
                          <SelectItem value="self-employed">Self-Employed</SelectItem>
                          <SelectItem value="retired">Retired</SelectItem>
                          <SelectItem value="unemployed">Unemployed</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="employer"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Employer Name</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="annualIncome"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Annual Income <span className="text-red-500">*</span></FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">$</span>
                          <Input
                            type="number"
                            className="pl-8"
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="creditScore"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Credit Score Range</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select range" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="excellent">Excellent (720+)</SelectItem>
                          <SelectItem value="good">Good (690-719)</SelectItem>
                          <SelectItem value="fair">Fair (630-689)</SelectItem>
                          <SelectItem value="poor">Below 630</SelectItem>
                          <SelectItem value="unknown">Don't know</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="mt-8 flex justify-between">
                <Button type="button" variant="outline" onClick={prevStep}>Back</Button>
                <Button type="button" onClick={nextStep}>Continue</Button>
              </div>
            </div>
          )}

          {/* Step 3: Loan Details */}
          {currentStep === 3 && (
            <div>
              <h3 className="text-xl font-semibold mb-6">Loan Preferences</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="loanPurpose"
                  render={({ field }) => (
                    <FormItem className="md:col-span-2">
                      <FormLabel>Loan Purpose <span className="text-red-500">*</span></FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select purpose" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="debt-consolidation">Debt Consolidation</SelectItem>
                          <SelectItem value="home-improvement">Home Improvement</SelectItem>
                          <SelectItem value="major-purchase">Major Purchase</SelectItem>
                          <SelectItem value="business">Business</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="loanAmount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Requested Loan Amount <span className="text-red-500">*</span></FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">$</span>
                          <Input
                            type="number"
                            className="pl-8"
                            min={5000}
                            max={100000}
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          />
                        </div>
                      </FormControl>
                      <FormDescription>
                        Enter amount between $5,000 and $100,000
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="loanTerm"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Preferred Loan Term <span className="text-red-500">*</span></FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select term" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="12">12 months</SelectItem>
                          <SelectItem value="24">24 months</SelectItem>
                          <SelectItem value="36">36 months</SelectItem>
                          <SelectItem value="48">48 months</SelectItem>
                          <SelectItem value="60">60 months</SelectItem>
                          <SelectItem value="72">72 months</SelectItem>
                          <SelectItem value="84">84 months</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="mt-8 flex justify-between">
                <Button type="button" variant="outline" onClick={prevStep}>Back</Button>
                <Button type="button" onClick={nextStep}>Review Application</Button>
              </div>
            </div>
          )}

          {/* Step 4: Review */}
          {currentStep === 4 && (
            <div>
              <h3 className="text-xl font-semibold mb-6">Review Your Application</h3>
              <Card className="mb-6">
                <CardContent className="pt-6">
                  <h4 className="font-semibold mb-4">Personal Information</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-500">Name:</p>
                      <p className="font-medium">
                        {form.watch('firstName')} {form.watch('lastName')}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-500">Email:</p>
                      <p className="font-medium">{form.watch('email')}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Phone:</p>
                      <p className="font-medium">{form.watch('phone')}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Address:</p>
                      <p className="font-medium">
                        {form.watch('address')}, {form.watch('city')}, {form.watch('zip')}
                      </p>
                    </div>
                  </div>

                  <h4 className="font-semibold mt-6 mb-4">Financial Information</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-500">Employment Status:</p>
                      <p className="font-medium">
                        {form.watch('employmentStatus') === 'employed'
                          ? 'Employed'
                          : form.watch('employmentStatus') === 'self-employed'
                          ? 'Self-Employed'
                          : form.watch('employmentStatus') === 'retired'
                          ? 'Retired'
                          : 'Unemployed'}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-500">Annual Income:</p>
                      <p className="font-medium">
                        ${form.watch('annualIncome').toLocaleString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-500">Credit Score Range:</p>
                      <p className="font-medium">
                        {form.watch('creditScore') === 'excellent'
                          ? 'Excellent (720+)'
                          : form.watch('creditScore') === 'good'
                          ? 'Good (690-719)'
                          : form.watch('creditScore') === 'fair'
                          ? 'Fair (630-689)'
                          : form.watch('creditScore') === 'poor'
                          ? 'Below 630'
                          : "Don't know"}
                      </p>
                    </div>
                  </div>

                  <h4 className="font-semibold mt-6 mb-4">Loan Details</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-500">Loan Purpose:</p>
                      <p className="font-medium">
                        {form.watch('loanPurpose') === 'debt-consolidation'
                          ? 'Debt Consolidation'
                          : form.watch('loanPurpose') === 'home-improvement'
                          ? 'Home Improvement'
                          : form.watch('loanPurpose') === 'major-purchase'
                          ? 'Major Purchase'
                          : form.watch('loanPurpose') === 'business'
                          ? 'Business'
                          : 'Other'}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-500">Loan Amount:</p>
                      <p className="font-medium">
                        ${form.watch('loanAmount').toLocaleString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-500">Loan Term:</p>
                      <p className="font-medium">{form.watch('loanTerm')} months</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <FormField
                control={form.control}
                name="termsAgreement"
                render={({ field }) => (
                  <FormItem className="mb-6">
                    <div className="flex items-start space-x-2">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>
                          I agree to the <a href="#" className="text-primary hover:underline">Terms of Service</a> and <a href="#" className="text-primary hover:underline">Privacy Policy</a>. I confirm that all information provided is accurate.
                        </FormLabel>
                        <FormMessage />
                      </div>
                    </div>
                  </FormItem>
                )}
              />

              <div className="mt-8 flex justify-between">
                <Button type="button" variant="outline" onClick={prevStep}>
                  Back
                </Button>
                <Button 
                  type="submit" 
                  variant="default" 
                  className="bg-green-600 hover:bg-green-700"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Submitting..." : "Submit Application"}
                </Button>
              </div>
            </div>
          )}
        </form>
      </Form>
    </div>
  );
}
