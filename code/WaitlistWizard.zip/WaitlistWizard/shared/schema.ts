import { pgTable, text, serial, integer, boolean, timestamp, real, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Loan application schema
export const loanApplications = pgTable("loan_applications", {
  id: serial("id").primaryKey(),
  // Personal Info
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  zip: text("zip").notNull(),
  
  // Financial Info
  employmentStatus: text("employment_status").notNull(),
  employer: text("employer"),
  annualIncome: real("annual_income").notNull(),
  creditScore: text("credit_score"),
  
  // Loan Info
  loanPurpose: text("loan_purpose").notNull(),
  loanAmount: real("loan_amount").notNull(),
  loanTerm: integer("loan_term").notNull(),
  
  // Status
  status: text("status").notNull().default("under_review"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  applicationData: json("application_data"),
});

export const insertLoanApplicationSchema = createInsertSchema(loanApplications)
  .omit({ id: true, status: true, createdAt: true });

export const applicationFormSchema = z.object({
  // Step 1: Personal Information
  firstName: z.string().min(2, { message: "First name must be at least 2 characters" }),
  lastName: z.string().min(2, { message: "Last name must be at least 2 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  phone: z.string().min(10, { message: "Please enter a valid phone number" }),
  address: z.string().min(5, { message: "Please enter your street address" }),
  city: z.string().min(2, { message: "Please enter your city" }),
  zip: z.string().regex(/^\d{5}(-\d{4})?$/, { message: "Please enter a valid ZIP code" }),
  
  // Step 2: Financial Information
  employmentStatus: z.enum(["employed", "self-employed", "retired", "unemployed"], {
    errorMap: () => ({ message: "Please select your employment status" }),
  }),
  employer: z.string().optional(),
  annualIncome: z.number().min(1, { message: "Please enter your annual income" }),
  creditScore: z.enum(["excellent", "good", "fair", "poor", "unknown"]).optional(),
  
  // Step 3: Loan Information
  loanPurpose: z.enum(["debt-consolidation", "home-improvement", "major-purchase", "business", "other"], {
    errorMap: () => ({ message: "Please select a loan purpose" }),
  }),
  loanAmount: z.number().min(5000, { message: "Minimum loan amount is $5,000" }).max(100000, { message: "Maximum loan amount is $100,000" }),
  loanTerm: z.enum(["12", "24", "36", "48", "60", "72", "84"], {
    errorMap: () => ({ message: "Please select a loan term" }),
  }),
  
  // Step 4: Terms agreement
  termsAgreement: z.literal(true, {
    errorMap: () => ({ message: "You must agree to the terms to continue" }),
  }),
});

export type InsertLoanApplication = z.infer<typeof insertLoanApplicationSchema>;
export type LoanApplication = typeof loanApplications.$inferSelect;
export type ApplicationFormData = z.infer<typeof applicationFormSchema>;
